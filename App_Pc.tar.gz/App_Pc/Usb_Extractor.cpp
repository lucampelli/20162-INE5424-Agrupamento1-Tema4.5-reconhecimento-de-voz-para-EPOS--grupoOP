#include <errno.h>
#include <fcntl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <termios.h>
#include <unistd.h>
#include <fstream>

#include "Usb_Extractor.h"
#include "Wav.h"

Usb_Extractor::Usb_Extractor() {

}

int Usb_Extractor::set_interface_attribs(int fd, int speed) {
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error from tcgetattr: %s\n", strerror(errno));
        return -1;
    }

    cfsetospeed(&tty, (speed_t) speed);
    cfsetispeed(&tty, (speed_t) speed);

    tty.c_cflag |= (CLOCAL | CREAD); /* ignore modem controls */
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8; /* 8-bit characters */
    tty.c_cflag &= ~PARENB; /* no parity bit */
    tty.c_cflag &= ~CSTOPB; /* only need 1 stop bit */
    tty.c_cflag &= ~CRTSCTS; /* no hardware flowcontrol */

    /* setup for non-canonical mode */
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    tty.c_oflag &= ~OPOST;

    /* fetch bytes as they become available */
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 1;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("Error from tcsetattr: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

void Usb_Extractor::set_mincount(int fd, int mcount) {
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error tcgetattr: %s\n", strerror(errno));
        return;
    }

    tty.c_cc[VMIN] = mcount ? 1 : 0;
    tty.c_cc[VTIME] = 5; /* half second timer */

    if (tcsetattr(fd, TCSANOW, &tty) < 0)
        printf("Error tcsetattr: %s\n", strerror(errno));
}

int Usb_Extractor::takeFromUSB() {
    char *portname = "/dev/ttyACM0"; //Port for taking information
    int fd;
    int wlen;
    printf("Trying to Open Archive\n");

    while (1) {
        while (access("/dev/ttyACM0", F_OK) == -1) sleep(1); //Until file do not exists

        fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
        if (fd < 0) {
            cout << "Error while opening archive" << errno << endl;
            return -1;
        }

        printf("Opened\n");
        /*baudrate 115200, 8 bits, no parity, 1 stop bit */
        set_interface_attribs(fd, B115200);

        /* simple noncanonical input */
        char buf;
        int rdlen;

        while (buf != ',') rdlen = read(fd, &buf, 1); //Caracter início

        printf("Criando Wav:\n");

        Wav* wave = new Wav("teste");

        while (buf != '.') {//Caracter Fim
            rdlen = read(fd, &buf, 1);
            if (rdlen > 0) {

                printf("Sample: %c", buf);
                wave->addSample(buf);

            } else if (rdlen < 0) {
                printf("Error from read: %d: %s\n", rdlen, strerror(errno));
            }
        }
        wave->endWav();
        close(fd);
        printf("Wav Criado\n");
    }

}

void Usb_Extractor::InsertInUSB(char* string) {

    char *portname = "/dev/ttyACM0"; //Port for taking information
    int fd;
    int wlen;

    while (access("/dev/ttyACM0", F_OK) == -1) sleep(1); //Until file do not exists

    fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) {
        cout << "Error while opening archive" << errno << endl;
        return;
    }

    wlen = write(fd, string, 16);
    if (wlen != 7) {
        printf("numero de caracteres: %d\n", wlen);
    }

}

void Usb_Extractor::USB_Sender() {

    while (1) {
        string inicio = "CTF ";
        string fim = "@";
        string output;
        stringstream ss;
        string s;
        
        while (access("/home/lucampelli/comand.txt", F_OK) == -1) sleep(10); //Until file do not exists
        ifstream comandFile;
        comandFile.open("/home/lucampelli/comand.txt");

        if (comandFile.is_open()) {
            getline(comandFile, output);
            int i = 0;
            while (output[i]) {
                output[i] = toupper(output[i]);
                i++;
            }
            ss << inicio << output << fim;
            s = ss.str();
        }

        char* saida = &s[0];
        printf("%s\n", saida);

        comandFile.close(); //Fechando arquivo
        //Apagando comand.txt
        if (remove("/home/lucampelli/comand.txt") != 0) {
            perror("Error deleting file");
        } else {
            puts("File successfully deleted");

            InsertInUSB(saida);
        }

    }
}