/* Apenas para propósito de teste.
Já que graças a dificuldades com sincronização de Threads bloqueantes, e com o Rádio, algumas alterações foram efetuadas para que se possa testar cada módulo individualmente. Ao inicializar o componente, deverá ser escolhido qual função será simulada, das duas possíveis, escolhendo com um T a primeira, e F a segunda. Caso esteja escolhido o módulo Sender, a primeira seria o módulo StandBy/Amostragem, e o segundo o módulo Receber/Agir. Para o módulo Receiver, a primeira seria rotear de uma mensagem recebida de um objeto para o computador, o segundo, rotear a mensagem do computador para um EPOS;*/

#ifndef RECORDER_H
#define RECORDER_H

#include "adc.h"
#include "nic.h"
#include "mutex.h"
#include "thread.h"
#include "usb.h"
#include "alarm.h"
#include <utility/ostream.h>
//#include "utility/string.h"

#define NOISE 20
#define SIZE 160
#define F_PERIOD 500
#define S_PERIOD 1000


using namespace EPOS;
__BEGIN_SYS

OStream cout;
ADC adc;
NIC * nic;
Mutex mutex;
Mutex Smutex;
Mutex Rmutex;
static const IEEE802_15_4::Protocol PROTOCOL = IEEE802_15_4::ELP;
bool action = false;

typedef void(Function)();

Function * _function[2];
char* _command[2];


//prints---------------------------------------------
template <typename T>
void print(T array){
	for(int j = 0; j < SIZE; j++){
		cout<<(array[j]);
	}
	//cout<<"TICK"<<endl;
}

//---------------------------------------------------

template <typename T>
int absMean(T array[], int size, int zero){
	int sum = 0;
	for(int i = 0; i < size; i++){
		int temp = array[i];
		temp -= zero;
		if(temp < 0){
			temp = -temp;
		}
		temp += zero;
		sum += temp;
	}
	return sum/size;
}

/*/---------------------------------------------------


*///---------------------------------------------------
//NIC------------------------------------------------
template<typename T>
int send(T array[]){
	NIC::Address dst = nic->broadcast();
		
	Smutex.lock();
	if(nic->send(dst,PROTOCOL,array,80)){
		//cout<<"Sent"<<endl;
	}
	nic->send(dst,PROTOCOL,&array[80],80);
	Smutex.unlock();
	return 0;
}

int send(char cmd){
	NIC::Address dst = nic->broadcast();
		
	Smutex.lock();
	if(nic->send(dst,PROTOCOL,&cmd,sizeof(unsigned char))){
		//cout<<"Sent"<<endl;
	}
	Smutex.unlock();
	return 0;
}

//--------------------------------------------------

bool contains(char* frase, char* token){
	int i = 0;
	int k = 0;
	while(frase[i] != '\0'){
		if(frase[i] == token[k]){
			int j = i;
			while(token[k] != '\0'){
				if(frase[i] != token[k]){
					i = j;
					k = 0;
					break;
				} else {
					i++;
					k++;
				}
			}
			if(i != j){
				return 1;
			}
		}
	i++;
	}
	return 0;
}

//Classes-------------------------------------------

class Sender : public IEEE802_15_4::Observer{
	    typedef char data_type;

	public:
	    typedef IEEE802_15_4::Protocol Protocol;
	    typedef IEEE802_15_4::Buffer Buffer;
	    typedef IEEE802_15_4::Frame Frame;
		typedef IEEE802_15_4::Observed Observed;

	public:
		Sender(){
			if(action){
				Thread thread1(&sample);
				Thread thread(&StandBy);
				thread.join();
				thread1.join();			
			} else {
				act();
			}
			
		}

		static int sample(){
			int i = 0;
			char samples[SIZE];

			while(true){
				mutex.lock();
				int times = 0;
				cout<<',';
				send(',');
				while(times < 3000){
					samples[i] = adc.read();
					i++;
					samples[i] = adc.read();
					i++;
					samples[i] = adc.read();
					i++;
					samples[i] = adc.read();
					i++;

					if(i > SIZE){
						i= 0;		
						send(samples);
						//print(samples);
					}
					times++;
					Alarm::delay(F_PERIOD);
				}
				cout<<'.';
				send('.');
				mutex.unlock();
				Alarm::delay(F_PERIOD);
			}
			
		}


		static int StandBy(){
			USB * usb = new USB();

			int i = 0;
			char samples[SIZE/4];
			int media = 0;
			int mediaTotal = 0;
			bool locked = false;
			while(true){
				if(!locked){
					mutex.lock();
					locked = true;
				}
				samples[i] = adc.read();
				media = absMean(samples, SIZE/4,0);
				cout<<"media: " << media << endl;
				if(usb->get() == 'o'){//media > NOISE + 64){
					cout<<"ok"<<endl;					
					mutex.unlock();
					locked = false;
					Alarm::delay(F_PERIOD);
				}
				i++;
				if(i > SIZE/4){
					i = 0;
				}
				Alarm::delay(F_PERIOD);
			}


		}

		//receives a command from PC and acts

		void update(Observed * o, Protocol p, Buffer * b){
        	cout << "Received buffer" << reinterpret_cast<void *>(b) << endl;
	        if(p == PROTOCOL) {
    	        Frame * f = reinterpret_cast<IEEE802_15_4::Frame *>(b->frame());
    	        data_type * d = f->data<data_type>();
    	        cout << endl << "=====================" << endl;
    	        cout << "Received " << b->size() << " bytes of payload from " << f->src() << " :" << endl;
    	        //for(int i=0; i<b->size()/sizeof(data_type); i++)
    	          //  cout << d[i] << " ";
				bool started = false;
	
				for(int j = 0; j < b->size()/sizeof(data_type); j++){
					if(!started){
						if(d[j] == 'C' && d[j+1] == 'T' && d[j+2] == 'F'){
							started = true;
							j += 2;
						}
					} else {
						if(contains(d,_command[0])){
							cout<<"Lights on"<<endl;
							if(_function[0]){
								_function[0]();
							} else {
								cout<<"Function not set"<<endl;
							}
						}
						if(contains(d,_command[1])){
							cout<<"Lights off"<<endl;
							if(_function[1]){
								_function[1]();
							} else {
								cout<<"Function not set"<<endl;
							}
						}
						break;
					}
				}
    	        cout << endl << "=====================" << endl;
    	        nic->free(b);
    	    }
		}

		int act(){			//done nic needs testing
			nic->attach(this,PROTOCOL);
			while(1);
		}

};

class Receiver : public IEEE802_15_4::Observer{

    typedef char data_type;

public:
    typedef IEEE802_15_4::Protocol Protocol;
    typedef IEEE802_15_4::Buffer Buffer;
    typedef IEEE802_15_4::Frame Frame;
    typedef IEEE802_15_4::Observed Observed;

	public:
		Receiver(){
			if(action){
				toPC();
			} else {
				Thread thread1(&toEPOS);
				thread1.join();
			}
		}

	
		int toPC(){			//for some reason nic was blocking usb... weird...
			nic->attach(this, PROTOCOL);
			while(1);
		}

		static int toEPOS(){		//pc to Epos works, Epos to Epos needs more testing...
			char msg[SIZE] = {};
			USB* usb = new USB();
			int i = 0;
			while(true){
				while(msg[i - 1] != '@'){
					msg[i] = usb->get();
					i++;
				}
				msg[i-1] = ' ';
				cout<<"got: ";
				cout<<msg<<endl;
				send(msg);
				i =0;
				msg ={};
			}
		}

		void update(Observed * o, Protocol p, Buffer * b){
        	//cout << "Received buffer" << reinterpret_cast<void *>(b) << endl;
	        if(p == PROTOCOL) {
    	        //led_value = !led_value;
    	        //led->set(led_value);
    	        Frame * f = reinterpret_cast<IEEE802_15_4::Frame *>(b->frame());
    	        data_type * d = f->data<data_type>();
    	        //cout << endl << "=====================" << endl;
    	        //cout << "Received " << b->size() << " bytes of payload from " << f->src() << " :" << endl;
    	        for(int i=0; i<b->size()/sizeof(data_type); i++)
    	            cout << d[i];
    	        //cout << endl << "=====================" << endl;
    	        nic->free(b);
    	    }
		}
};

class REC{

	public:
	REC(){
	}

	void addFunc(Function * f,char* command, int place){
		cout<<"changed"<<endl;
		_function[place] = f;
		_command[place] = command;
	}

	void start(){
		USB* usb = new USB();
		if(usb->get() == 'T'){
			action = true;
		} else {
			action = false;
		}
		delete usb;
		nic = new NIC();
		IF_CLASS<Traits<REC>::send,Sender,Receiver>::Result op;
	}
};

__END_SYS
#endif
