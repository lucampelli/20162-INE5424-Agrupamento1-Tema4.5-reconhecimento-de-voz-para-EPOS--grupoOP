// EPOS Page Coloring Implementation

#include <utility/malloc.h>

__BEGIN_SYS

// Class attributes
Segment * Page_Coloring::_segment[COLORS];
Heap * Page_Coloring::_heap[COLORS];

__END_SYS
