// EPOS PC Display Mediator Implementation

#include <display.h>

__BEGIN_SYS

// Class attributes
VGA::Frame_Buffer VGA::_frame_buffer;

__END_SYS
