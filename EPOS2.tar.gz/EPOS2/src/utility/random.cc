#include <utility/random.h>

__BEGIN_UTIL

int Random::_seed;

__END_UTIL
